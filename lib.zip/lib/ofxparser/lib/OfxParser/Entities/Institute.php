<?php

namespace OfxParser\Entities;

class Institute extends AbstractEntity
{
    /**
     * @var string
     */
    public $id;

    /**
     * @var string
     */
    public $name;
}
