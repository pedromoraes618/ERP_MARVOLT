<?php

namespace OfxParser\Entities\Investment\Transaction;

class Reinvest extends Income
{
    /**
     * @var string
     */
    public $nodeName = 'REINVEST';
}
